import sys
sys.path.insert(0, '../')
import ctypes
import elina_linexpr0_h

from elina_auxiliary_imports import *
from elina_interval import *
from tests.test_imports import *
from zonoml import *
from elina_abstract0 import *
from elina_manager import elina_manager_free
from elina_linexpr0 import *
from elina_scalar import *
from elina_dimension import *


man = zonoml_manager_alloc()
specLB = [0.121569, 0.517647, 0.996078, 0.992157, 0.996078, 0.835294, 0.321569, 0.0, 0.0, 0.0823529, 0.835294, 0.321569]
specUB = [0.121569, 0.517647, 1.0, 1.0, 1.0, 0.835294, 0.321569, 0.0, 0.0, 0.0823529, 0.835294, 0.321569]


size = c_size_t(len(specLB))

# produce an interval array
interval_array = elina_interval_array_alloc(size)
for i in range(size.value):
	elina_interval_set_double(interval_array[i], specLB[i], specUB[i])


# port these intervals over to the octagon domain
obj = elina_abstract0_of_box(man, 0, size, interval_array)
dims = elina_abstract0_dimension(man, obj)
print("Dimensionality:",dims.intdim+dims.realdim)



# produce two linear expressions that add 10 to the 7th and 8th dimension
linexprs = elina_linexpr0_array_alloc(2)
for i in range(2):
	linexprs[i] = elina_linexpr0_alloc(ElinaLinexprDiscr.ELINA_LINEXPR_SPARSE, size)
scalar = elina_scalar_alloc()
elina_scalar_set_double(scalar, 10)

for i in range(2):
	elina_linexpr0_set_cst_scalar(linexprs[i], scalar)


# now assign these two linear expressions
# here comes the intressting part: if I use the loop everything goes as it should, but if I use the assignment with the actual array it doesn't (evey variable is set to [1, -1], so bottom)
"""
for i in range(2):
	obj = elina_abstract0_assign_linexpr_array(man,True,obj,ElinaDim(i+7),linexprs[i],1,None)
"""
obj = elina_abstract0_assign_linexpr_array(man,True,obj,(c_uint * 2)(ElinaDim(7), ElinaDim(8)),linexprs,2,None)

# print out the bounding box
box = elina_abstract0_to_box(man, obj)
for i in range(size.value):
	elina_interval_fprint(cstdout, box[i])
	print_c("\n")
	
	
	
	
	
	
	

elina_scalar_free(scalar)
[elina_linexpr0_free(linexprs[i]) for i in range(2)]
#elina_linexpr0_array_free(linexprs, size) TODO seems like it is not implemented yet/ results in a segmentation fault
elina_abstract0_free(man, obj)
elina_interval_array_free(interval_array, size)
elina_interval_array_free(box, size)
elina_manager_free(man)





