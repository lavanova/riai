/*
 *
 *  This source file is part of ELINA (ETH LIbrary for Numerical Analysis).
 *  ELINA is Copyright © 2018 Department of Computer Science, ETH Zurich
 *  This software is distributed under GNU Lesser General Public License Version 3.0.
 *  For more information, see the ELINA project website at:
 *  http://elina.ethz.ch
 *
 *  THE SOFTWARE IS PROVIDED "AS-IS" WITHOUT ANY WARRANTY OF ANY KIND, EITHER
 *  EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO ANY WARRANTY
 *  THAT THE SOFTWARE WILL CONFORM TO SPECIFICATIONS OR BE ERROR-FREE AND ANY
 *  IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *  TITLE, OR NON-INFRINGEMENT.  IN NO EVENT SHALL ETH ZURICH BE LIABLE FOR ANY     
 *  DAMAGES, INCLUDING BUT NOT LIMITED TO DIRECT, INDIRECT,
 *  SPECIAL OR CONSEQUENTIAL DAMAGES, ARISING OUT OF, RESULTING FROM, OR IN
 *  ANY WAY CONNECTED WITH THIS SOFTWARE (WHETHER OR NOT BASED UPON WARRANTY,
 *  CONTRACT, TORT OR OTHERWISE).
 *
 */

#include "zonobest_fun.h"

/****************/
/* Constructors */
/****************/
/* 1.Basic constructors */
zonobest_t* zonobest_bottom(elina_manager_t* man, size_t intdim, size_t realdim)
{
    start_timing();
    zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_BOTTOM);
    zonobest_t* res = (zonobest_t *)malloc(sizeof(zonobest_t));
    res->lzo = zonotope_bottom(pr->man_zono,intdim,realdim);
    res->uzo = zonotope_bottom(pr->man_zono,intdim,realdim);
    man->result.flag_best = true;
    man->result.flag_exact = true;
    record_timing(zonobest_bottom_time);
    return res;
}


zonobest_t* zonobest_top(elina_manager_t* man, size_t intdim, size_t realdim)
{
    start_timing();
    zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_TOP);
    zonobest_t* res = (zonobest_t *)malloc(sizeof(zonobest_t));
    res->lzo = zonotope_top(pr->man_zono,intdim,realdim);
    res->uzo = zonotope_top(pr->man_zono,intdim,realdim);
    man->result.flag_best = true;
    man->result.flag_exact = true;
    record_timing(zonobest_top_time);
    return res;
}

/* Abstract an hypercube defined by the array of intervals of size intdim+realdim */
zonobest_t* zonobest_of_box(elina_manager_t* man, size_t intdim, size_t realdim, elina_interval_t** tinterval)
{
    start_timing();
    zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_OF_BOX);
    zonotope_internal_t *zpr = zonotope_init_from_manager(pr->man_zono, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
    zonobest_t* res = (zonobest_t *)malloc(sizeof(zonobest_t));
    res->lzo = zonotope_of_box(pr->man_zono,intdim,realdim,tinterval);
    res->uzo = zonotope_copy(pr->man_zono,res->lzo);
    man->result.flag_best = true;
    man->result.flag_exact = true;
    record_timing(zonobest_of_box_time);
    return res;
}

/* access the dimensions of the abstract value */
elina_dimension_t zonobest_dimension(elina_manager_t* man, zonobest_t* zo){
    zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_DIMENSION);
    elina_dimension_t res = zonotope_dimension(pr->man_zono,zo->lzo);
    man->result.flag_best = true;
    man->result.flag_exact = true;
    return res;
}

/* Return a copy of an abstract value */
zonobest_t * zonobest_copy(elina_manager_t* man, zonobest_t *zo){
    start_timing();
    zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_COPY);
    zonobest_t * res = (zonobest_t *)malloc(sizeof(zonobest_t));
    res->lzo = zonotope_copy(pr->man_zono,zo->lzo);
    res->uzo = zonotope_copy(pr->man_zono,zo->uzo);
    record_timing(zonobest_copy_time);
    return res;
}


/* free an abstract value */
void  zonobest_free(elina_manager_t *man, zonobest_t *zo){
	start_timing();
	zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_FREE);
	zonotope_free(pr->man_zono,zo->lzo);
        zonotope_free(pr->man_zono,zo->uzo);
	free(zo);
	record_timing(zonobest_free_time);
}

/* check if an abstract element is top */
bool zonobest_is_top(elina_manager_t *man, zonobest_t *zo){
	start_timing();
	zonobest_internal_t *pr = zonobest_init_from_manager(man,ELINA_FUNID_IS_TOP);
	bool res = zonotope_is_top(pr->man_zono,zo->lzo) && zonotope_is_top(pr->man_zono,zo->uzo);
	record_timing(zonobest_is_top_time);
	return res;
}

/* check if an abstract element is bottom */
bool zonobest_is_bottom(elina_manager_t *man, zonobest_t *zo){
	start_timing();
	zonobest_internal_t *pr = zonobest_init_from_manager(man,ELINA_FUNID_IS_TOP);
	bool res =  zonotope_is_bottom(pr->man_zono,zo->lzo) || zonotope_is_bottom(pr->man_zono,zo->uzo);
	record_timing(zonobest_is_bottom_time);
	return res;
}

/* Extract the smallest box bounding an abstract element*/
elina_interval_t** zonobest_to_box(elina_manager_t* man, zonobest_t* zo){
    start_timing();
    zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_TO_BOX);
    elina_interval_t **lres = zonotope_to_box(pr->man_zono,zo->lzo);
    elina_interval_t **ures = zonotope_to_box(pr->man_zono,zo->uzo);
    elina_dimension_t dim = zonobest_dimension(man,zo);
    elina_interval_t **res = elina_interval_array_alloc(dim.intdim + dim.realdim);
    size_t i;
    for(i=0; i < dim.intdim + dim.realdim; i++){
	elina_interval_set_scalar(res[i],lres[i]->inf,ures[i]->sup);
	elina_interval_free(lres[i]);
	elina_interval_free(ures[i]);
    }
    free(lres);
    free(ures);
    man->result.flag_best = true;
    man->result.flag_exact = true;
    record_timing(zonobest_to_box_time);
    return res;

}


/* Extract the interval for a dimension */
elina_interval_t* zonobest_bound_dimension(elina_manager_t* man, zonobest_t* zo, elina_dim_t dim)
{
    zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_BOUND_DIMENSION);
    elina_interval_t* lres = zonotope_bound_dimension(pr->man_zono,zo->lzo,dim);
    elina_interval_t* ures = zonotope_bound_dimension(pr->man_zono,zo->uzo,dim);
    elina_interval_t* res = elina_interval_alloc();
    elina_interval_set_scalar(res,lres->inf,ures->sup);
    elina_interval_free(lres);
    elina_interval_free(ures);
    return res;
}

/* forget  dimensions in an abstract element */
zonobest_t* zonobest_forget_array(elina_manager_t* man, bool destructive, zonobest_t* zo,
				  elina_dim_t* tdim, size_t size, bool project){
    start_timing();
    zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_FORGET_ARRAY); 
    zonobest_t *res = destructive ? zo : (zonobest_t *)malloc(sizeof(zonobest_t));
    res->lzo = zonotope_forget_array(pr->man_zono,destructive,zo->lzo,tdim,size,project);
    res->uzo = zonotope_forget_array(pr->man_zono,destructive,zo->uzo,tdim,size,project);
    record_timing(zonobest_forget_dimensions_time);
  
    return res;
}

/* add dimensions to an abstract element */
zonobest_t* zonobest_add_dimensions(elina_manager_t* man, bool destructive, zonobest_t* zo, elina_dimchange_t* dimchange, bool project){
    start_timing();
    zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_ADD_DIMENSIONS);
    zonobest_t *res = destructive ? zo : (zonobest_t *)malloc(sizeof(zonobest_t));
    res->lzo = zonotope_add_dimensions(pr->man_zono,destructive,zo->lzo,dimchange,project);
    res->uzo = zonotope_add_dimensions(pr->man_zono,destructive,zo->uzo,dimchange,project);
    record_timing(zonobest_add_dimensions_time);
    return res;
}

/* remove dimesnions form an abstract element */
zonobest_t* zonobest_remove_dimensions(elina_manager_t* man, bool destructive, zonobest_t* zo, elina_dimchange_t* dimchange){
    start_timing();
    zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_REMOVE_DIMENSIONS);
    zonobest_t *res = destructive ? zo : (zonobest_t *)malloc(sizeof(zonobest_t));
    res->lzo = zonotope_remove_dimensions(pr->man_zono,destructive,zo->lzo,dimchange);
    res->uzo = zonotope_remove_dimensions(pr->man_zono,destructive,zo->uzo,dimchange);
    record_timing(zonobest_remove_dimensions_time);
    return res;
}

/* permute dimensions in an abstract element */
zonobest_t* zonobest_permute_dimensions(elina_manager_t* man, bool destructive, zonobest_t* zo, elina_dimperm_t* permutation){
	start_timing();
	zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_ADD_DIMENSIONS);
    	zonobest_t *res = destructive ? zo : (zonobest_t *)malloc(sizeof(zonobest_t));
   	res->lzo = zonotope_permute_dimensions(pr->man_zono,destructive,zo->lzo,permutation);
    	res->uzo = zonotope_permute_dimensions(pr->man_zono,destructive,zo->uzo,permutation);
	record_timing(zonobest_permute_dimensions_time);
	return res;
}


/* assign linear expression*/
zonobest_t* zonobest_assign_linexpr_array(elina_manager_t* man, bool destructive, zonobest_t* zo, 
				      elina_dim_t* tdim, elina_linexpr0_t** lexpr, 
				      size_t size, zonobest_t* dest){
	start_timing();
	zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
	
	zonobest_t *res = destructive? zo : (zonobest_t *)malloc(sizeof(zonobest_t));
	zonotope_t *dest_lzo = (dest==NULL)? NULL : dest->lzo;
	zonotope_t *dest_uzo = (dest==NULL)? NULL : dest->uzo;
	bool flag = true;
	size_t i;
	for(i=0; i < size; i++){
		if(lexpr[i]->size>1){
			flag = false;
			break;
		}
	}
	//if( flag){
		//printf("coming here\n");
		//fflush(stdout);
		res->lzo = zonotope_assign_linexpr_array(pr->man_zono,destructive,zo->lzo,tdim,lexpr,size,dest_lzo); 
		if(flag)
		res->uzo = zonotope_assign_linexpr_array(pr->man_zono,destructive,zo->uzo,tdim,lexpr,size,dest_uzo);
		else if(pr->numlayers==0){
        		res->uzo = zonotope_copy(pr->man_zono,res->lzo);//zonotope_assign_linexpr_array(pr->man_zono,destructive,zo->uzo,tdim,lexpr,size,dest_uzo);
			pr->numlayers++;
		}
	//} 	
	//else{
	//	res = zonobest_relu_assign_linexpr_array(man,destructive,(elina_abstract0_t *)zo,tdim,lexpr,size);
	//}
	record_timing(zonobest_assign_linexpr_time);
	return res;
}


/* meet lincons array */
zonobest_t* zonobest_meet_lincons_array(elina_manager_t* man, bool destructive, zonobest_t *zo, elina_lincons0_array_t *array){
	start_timing();
	zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_MEET_LINCONS_ARRAY);
	//printf("start\n");
	//zonobest_fprint(stdout,man,zo,NULL);
	//fflush(stdout);
	
	zonobest_t *res = destructive? zo : (zonobest_t *)malloc(sizeof(zonobest_t));
	res->lzo = zonotope_meet_lincons_array(pr->man_zono,destructive,zo->lzo,array);
	elina_dimension_t dims = zonobest_dimension(man,zo);
	if(zonotope_is_bottom(pr->man_zono,zo->lzo)){
		if(destructive){
			printf("bottom1\n");
			zonotope_free(pr->man_zono,zo->lzo);
		 	zonotope_free(pr->man_zono,zo->uzo);
			res->lzo = zonotope_bottom(pr->man_zono,dims.intdim,dims.realdim);
		        res->uzo = zonotope_bottom(pr->man_zono,dims.intdim,dims.realdim);
			return res;
		}
		else{
			free(res);
			return zonobest_bottom(man,dims.intdim,dims.realdim);
		}
		
	}

	res->uzo = zonotope_meet_lincons_array(pr->man_zono,destructive,zo->uzo,array);
	if(zonotope_is_bottom(pr->man_zono,zo->uzo)){
		printf("bottom2\n");
		if(destructive){
			zonotope_free(pr->man_zono,zo->lzo);
		 	zonotope_free(pr->man_zono,zo->uzo);
			res->lzo = zonotope_bottom(pr->man_zono,dims.intdim,dims.realdim);
		        res->uzo = zonotope_bottom(pr->man_zono,dims.intdim,dims.realdim);
			return res;
		}
		else{
			free(res);
			return zonobest_bottom(man,dims.intdim,dims.realdim);
		}
		
	}
	record_timing(zonobest_meet_lincons_time);
	//printf("end\n");
	//zonobest_fprint(stdout,man,res,NULL);
	//fflush(stdout);
	return res;
}



/* printing */
void zonobest_fprint(FILE* stream, elina_manager_t* man, zonobest_t* zo, char** name_of_dim){
	zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_FPRINT);
   	zonotope_fprint(stream,pr->man_zono,zo->lzo,name_of_dim);
    	zonotope_fprint(stream,pr->man_zono,zo->uzo,name_of_dim);
}

elina_lincons0_array_t zonobest_to_lincons_array(elina_manager_t* man, zonobest_t* zo){
	zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_TO_LINCONS_ARRAY);
	elina_interval_t ** box = zonobest_to_box(man,zo);
	elina_dimension_t dim = zonobest_dimension(man,zo);
	size_t num_dim = dim.intdim + dim.realdim;
    	elina_lincons0_array_t res = elina_lincons0_array_make(2*num_dim);
	size_t i;
	for(i=0; i < num_dim; i++){
		//Lower bound
		res.p[2*i].constyp = ELINA_CONS_SUPEQ;
		elina_linexpr0_t *lexpr = elina_linexpr0_alloc(ELINA_LINEXPR_SPARSE,1);
		elina_coeff_t *cst = &lexpr->cst;
		elina_scalar_t * tmp = elina_scalar_alloc();
		elina_scalar_neg(tmp,box[i]->inf);
		elina_scalar_set(cst->val.scalar,tmp);
		elina_scalar_free(tmp);
		elina_linterm_t * linterm = &lexpr->p.linterm[0];
		linterm->dim = i;
		elina_coeff_t *coeff = &linterm->coeff;
		elina_scalar_set_double(coeff->val.scalar,1.0);
		res.p[2*i].linexpr0 = lexpr;

		//Upper Bound
		res.p[2*i+1].constyp = ELINA_CONS_SUPEQ;
		elina_linexpr0_t *uexpr = elina_linexpr0_alloc(ELINA_LINEXPR_SPARSE,1);
		cst = &uexpr->cst;
		elina_scalar_set(cst->val.scalar,box[i]->sup);
		linterm = &uexpr->p.linterm[0];
		linterm->dim = i;
		coeff = &linterm->coeff;
		elina_scalar_set_double(coeff->val.scalar,-1.0);
		res.p[2*i+1].linexpr0 = uexpr;
		
		elina_interval_free(box[i]);
	}
	free(box);
	return res;
}

