/*
 *
 *  This source file is part of ELINA (ETH LIbrary for Numerical Analysis).
 *  ELINA is Copyright © 2018 Department of Computer Science, ETH Zurich
 *  This software is distributed under GNU Lesser General Public License Version 3.0.
 *  For more information, see the ELINA project website at:
 *  http://elina.ethz.ch
 *
 *  THE SOFTWARE IS PROVIDED "AS-IS" WITHOUT ANY WARRANTY OF ANY KIND, EITHER
 *  EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO ANY WARRANTY
 *  THAT THE SOFTWARE WILL CONFORM TO SPECIFICATIONS OR BE ERROR-FREE AND ANY
 *  IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *  TITLE, OR NON-INFRINGEMENT.  IN NO EVENT SHALL ETH ZURICH BE LIABLE FOR ANY     
 *  DAMAGES, INCLUDING BUT NOT LIMITED TO DIRECT, INDIRECT,
 *  SPECIAL OR CONSEQUENTIAL DAMAGES, ARISING OUT OF, RESULTING FROM, OR IN
 *  ANY WAY CONNECTED WITH THIS SOFTWARE (WHETHER OR NOT BASED UPON WARRANTY,
 *  CONTRACT, TORT OR OTHERWISE).
 *
 */


#ifndef _ZONOBEST_FUN_H_
#define _ZONOBEST_FUN_H_

#include "zonobest.h"
#include "zonobest_internal.h"
#include "zonobest_mltransformers.h"


#ifdef __cplusplus
extern "C" {
#endif

/****************/
/* Constructors */
/****************/
/* Basic constructors */
zonobest_t* zonobest_bottom(elina_manager_t* man, size_t intdim, size_t realdim);
zonobest_t* zonobest_top(elina_manager_t* man, size_t intdim, size_t realdim);
zonobest_t* zonobest_of_box(elina_manager_t* man, size_t intdim, size_t realdim, elina_interval_t** tinterval);

/* Accessors */
elina_dimension_t zonobest_dimension(elina_manager_t* man, zonobest_t* a);

/*memory management */
zonobest_t * zonobest_copy(elina_manager_t* man, zonobest_t *zo);
void  zonobest_free(elina_manager_t *man, zonobest_t *zo);

/* predicate functions */
bool zonobest_is_top(elina_manager_t *man, zonobest_t *zo);
bool zonobest_is_bottom(elina_manager_t *man, zonobest_t *zo);

/* Extraction function */
elina_interval_t** zonobest_to_box(elina_manager_t* man, zonobest_t* zo);
elina_interval_t* zonobest_bound_dimension(elina_manager_t* man, zonobest_t* zo, elina_dim_t dim);

/* resize functions */
zonobest_t* zonobest_forget_array(elina_manager_t* man, bool destructive, zonobest_t* zo, elina_dim_t* tdim, size_t size, bool project);
zonobest_t* zonobest_add_dimensions(elina_manager_t* man, bool destructive, zonobest_t* zo, elina_dimchange_t* dimchange, bool project);
zonobest_t* zonobest_remove_dimensions(elina_manager_t* man, bool destructive, zonobest_t* zo, elina_dimchange_t* dimchange);
zonobest_t* zonobest_permute_dimensions(elina_manager_t* man, bool destructive, zonobest_t* zo, elina_dimperm_t* permutation);


/* assign linexpr */
zonobest_t* zonobest_assign_linexpr_array(elina_manager_t* man, bool destructive, zonobest_t* zo, elina_dim_t* tdim, elina_linexpr0_t** lexpr, size_t size, zonobest_t* dest);

/* meet lincons */
zonobest_t* zonobest_meet_lincons_array(elina_manager_t* man, bool destructive, zonobest_t *zo, elina_lincons0_array_t *lincons);

/*  printing */
void zonobest_fprint(FILE* stream, elina_manager_t* man, zonobest_t* zo, char** name_of_dim);
elina_lincons0_array_t zonobest_to_lincons_array(elina_manager_t* man, zonobest_t* zo);

#ifdef __cplusplus
}
#endif

#endif
