/*
 *
 *  This source file is part of ELINA (ETH LIbrary for Numerical Analysis).
 *  ELINA is Copyright © 2018 Department of Computer Science, ETH Zurich
 *  This software is distributed under GNU Lesser General Public License Version 3.0.
 *  For more information, see the ELINA project website at:
 *  http://elina.ethz.ch
 *
 *  THE SOFTWARE IS PROVIDED "AS-IS" WITHOUT ANY WARRANTY OF ANY KIND, EITHER
 *  EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO ANY WARRANTY
 *  THAT THE SOFTWARE WILL CONFORM TO SPECIFICATIONS OR BE ERROR-FREE AND ANY
 *  IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *  TITLE, OR NON-INFRINGEMENT.  IN NO EVENT SHALL ETH ZURICH BE LIABLE FOR ANY     
 *  DAMAGES, INCLUDING BUT NOT LIMITED TO DIRECT, INDIRECT,
 *  SPECIAL OR CONSEQUENTIAL DAMAGES, ARISING OUT OF, RESULTING FROM, OR IN
 *  ANY WAY CONNECTED WITH THIS SOFTWARE (WHETHER OR NOT BASED UPON WARRANTY,
 *  CONTRACT, TORT OR OTHERWISE).
 *
 */

#include <stdlib.h>
#include <unistd.h>

#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <sys/mman.h>


#include "zonobest_internal.h"

#include "zonobest_fun.h"

double zonobest_copy_time=0;
double zonobest_is_equal_time=0;
double zonobest_is_lequal_time=0;
double zonobest_permute_dimensions_time=0;
double zonobest_add_dimensions_time=0;
double zonobest_remove_dimensions_time=0;
double zonobest_top_time=0;
double zonobest_bottom_time=0;
double zonobest_join_time=0;
double zonobest_free_time=0;
double zonobest_forget_dimensions_time=0;
double zonobest_meet_lincons_time=0;
double zonobest_to_box_time=0;
double zonobest_of_box_time=0;
double zonobest_is_top_time=0;
double zonobest_is_bottom_time=0;
double zonobest_assign_linexpr_time=0;
int flag = 1;
int count = 0;

elina_manager_t* zonobest_manager_alloc(void)
{
	elina_manager_t* man;
	void** funptr;
	elina_manager_t* man_zono = zonotope_manager_alloc();
	zonobest_internal_t *pr = zonobest_internal_alloc(man_zono);

	man = elina_manager_alloc("Zonobest",/* Library name */
			"1.0", /* version */
			pr, /* internal structure */
			(void (*)(void*))zonobest_internal_free /* free function for internal */
			);

	funptr = man->funptr;

	/* Internal representation */
	/***************************/
	/* 1.Memory */
	funptr[ELINA_FUNID_COPY] = &zonobest_copy;
	funptr[ELINA_FUNID_FREE] = &zonobest_free;
	/* 3.Printing */
	funptr[ELINA_FUNID_FPRINT] = &zonobest_fprint;

	/* Constructors */
	/****************/
	/* 1.Basic constructors */
	funptr[ELINA_FUNID_BOTTOM] = &zonobest_bottom;
	funptr[ELINA_FUNID_TOP] = &zonobest_top;
	funptr[ELINA_FUNID_OF_BOX] = &zonobest_of_box;
	/* 2.Accessors */
	funptr[ELINA_FUNID_DIMENSION] = &zonobest_dimension;
	/* 3.Tests */
	funptr[ELINA_FUNID_IS_BOTTOM] = &zonobest_is_bottom;
	funptr[ELINA_FUNID_IS_TOP] = &zonobest_is_top;
	
	/* 4.Extraction of properties */
	funptr[ELINA_FUNID_BOUND_DIMENSION] = &zonobest_bound_dimension;
	funptr[ELINA_FUNID_TO_BOX] = &zonobest_to_box;
	funptr[ELINA_FUNID_TO_LINCONS_ARRAY] = &zonobest_to_lincons_array;

	/* Meet and Join */
	/*****************/
	/* 1.Meet */
	funptr[ELINA_FUNID_MEET_LINCONS_ARRAY] = &zonobest_meet_lincons_array; /*  */
	/* 2.Join */


	/* Assign and Substitute */
	/*************************/
	funptr[ELINA_FUNID_ASSIGN_LINEXPR_ARRAY] = &zonobest_assign_linexpr_array;


	/* Resize dimensions */
	/*********************/
	funptr[ELINA_FUNID_ADD_DIMENSIONS] = &zonobest_add_dimensions;
	funptr[ELINA_FUNID_REMOVE_DIMENSIONS] = &zonobest_remove_dimensions;
	funptr[ELINA_FUNID_PERMUTE_DIMENSIONS] = &zonobest_permute_dimensions;

	/* Other functions */
	/*******************/
	funptr[ELINA_FUNID_FORGET_ARRAY] = &zonobest_forget_array;
	man->option.abort_if_exception[ELINA_EXC_INVALID_ARGUMENT] = false;
	return man;
}
