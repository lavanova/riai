/*
 *
 *  This source file is part of ELINA (ETH LIbrary for Numerical Analysis).
 *  ELINA is Copyright © 2018 Department of Computer Science, ETH Zurich
 *  This software is distributed under GNU Lesser General Public License Version 3.0.
 *  For more information, see the ELINA project website at:
 *  http://elina.ethz.ch
 *
 *  THE SOFTWARE IS PROVIDED "AS-IS" WITHOUT ANY WARRANTY OF ANY KIND, EITHER
 *  EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO ANY WARRANTY
 *  THAT THE SOFTWARE WILL CONFORM TO SPECIFICATIONS OR BE ERROR-FREE AND ANY
 *  IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *  TITLE, OR NON-INFRINGEMENT.  IN NO EVENT SHALL ETH ZURICH BE LIABLE FOR ANY     
 *  DAMAGES, INCLUDING BUT NOT LIMITED TO DIRECT, INDIRECT,
 *  SPECIAL OR CONSEQUENTIAL DAMAGES, ARISING OUT OF, RESULTING FROM, OR IN
 *  ANY WAY CONNECTED WITH THIS SOFTWARE (WHETHER OR NOT BASED UPON WARRANTY,
 *  CONTRACT, TORT OR OTHERWISE).
 *
 */


#ifndef _ZONOBEST_INTERNAL_H_
#define _ZONOBEST_INTERNAL_H_

#include <time.h>
#include <limits.h>
#include <unistd.h>
#include <string.h>
#include  <fenv.h>
#include <errno.h>
#include "zonotope.h"
#include "zonobest.h"
#include "rdtsc.h"



#ifdef __cplusplus
extern "C" {
#endif

#define start_timing()				\
tsc_counter start, end;				\
double cycles;					\
CPUID();					\
RDTSC(start)
    
#define record_timing(counter)		\
RDTSC(end);				\
CPUID();				\
cycles = (double)(COUNTER_DIFF(end, start));	\
counter += cycles
    
    extern double zonobest_copy_time;
    extern double zonobest_is_equal_time;
    extern double zonobest_is_lequal_time;
    extern double zonobest_permute_dimensions_time;
    extern double zonobest_add_dimensions_time;
    extern double zonobest_remove_dimensions_time;
    extern double zonobest_top_time;
    extern double zonobest_bottom_time;
    extern double zonobest_join_time;
    extern double zonobest_free_time;
    extern double zonobest_forget_dimensions_time;
    extern double zonobest_meet_lincons_time;
    extern double zonobest_to_box_time;
    extern double zonobest_of_box_time;
    extern double zonobest_is_top_time;
    extern double zonobest_is_bottom_time;
    extern double zonobest_assign_linexpr_time;
    extern int flag;
    extern int count;

typedef struct zonobest_internal_t{
  /* Name of function */
  elina_funid_t funid;

  /* local parameters for the function */
  elina_funopt_t* funopt;
  //zonotope manager
  elina_manager_t * man_zono;
  /* raised when a conversion from/to a user type resulted in an
     overapproximation
  */
  bool conv;
  int numlayers;
  /* back pointer to elina_manager*/
  elina_manager_t* man;
}zonobest_internal_t;




/* called by each function to setup and get manager-local data */
static inline zonobest_internal_t* zonobest_init_from_manager(elina_manager_t* man, elina_funid_t id)
{
  //printf("id: %d\n",id);
  //fflush(stdout);
  zonobest_internal_t* pr = (zonobest_internal_t*) man->internal;
  pr->funid = id;
  pr->funopt = man->option.funopt+id;
  man->result.flag_exact = man->result.flag_best = true;
  pr->conv = false;
  if(!pr->man){
	pr->man = man;
  }
  return pr;
}


static inline void zonobest_internal_free(zonobest_internal_t* pr)
{
    if (pr) {
	pr->funid = ELINA_FUNID_UNKNOWN;
	elina_manager_free(pr->man_zono);
	pr->man_zono=NULL; 
	free(pr);
	pr = NULL;
    }
}


static inline zonobest_internal_t* zonobest_internal_alloc(elina_manager_t* man_zono)
{
    zonobest_internal_t* pr = (zonobest_internal_t*)malloc(sizeof(zonobest_internal_t));
    pr->funid = ELINA_FUNID_UNKNOWN;
    pr->man = NULL;
    pr->funopt = NULL; 
    pr->man_zono = man_zono; 
    pr->numlayers = 0;
    return pr;
}

#ifdef __cplusplus
}
#endif

#endif
