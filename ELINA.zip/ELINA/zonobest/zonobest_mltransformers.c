/*
 *
 *  This source file is part of ELINA (ETH LIbrary for Numerical Analysis).
 *  ELINA is Copyright © 2018 Department of Computer Science, ETH Zurich
 *  This software is distributed under GNU Lesser General Public License Version 3.0.
 *  For more information, see the ELINA project website at:
 *  http://elina.ethz.ch
 *
 *  THE SOFTWARE IS PROVIDED "AS-IS" WITHOUT ANY WARRANTY OF ANY KIND, EITHER
 *  EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO ANY WARRANTY
 *  THAT THE SOFTWARE WILL CONFORM TO SPECIFICATIONS OR BE ERROR-FREE AND ANY
 *  IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *  TITLE, OR NON-INFRINGEMENT.  IN NO EVENT SHALL ETH ZURICH BE LIABLE FOR ANY     
 *  DAMAGES, INCLUDING BUT NOT LIMITED TO DIRECT, INDIRECT,
 *  SPECIAL OR CONSEQUENTIAL DAMAGES, ARISING OUT OF, RESULTING FROM, OR IN
 *  ANY WAY CONNECTED WITH THIS SOFTWARE (WHETHER OR NOT BASED UPON WARRANTY,
 *  CONTRACT, TORT OR OTHERWISE).
 *
 */

#include "zonobest_mltransformers.h"

zonobest_t* zonobest_of_abstract0(elina_abstract0_t* a)
{
  return (zonobest_t*)a->value;
}

elina_abstract0_t* abstract0_of_zonobest(elina_manager_t* man, zonobest_t* zo)
{
  elina_abstract0_t* r = malloc(sizeof(elina_abstract0_t));
  assert(r);
  r->value = zo;
  r->man = elina_manager_copy(man);
  return r;
}


zonotope_aff_t * zonotope_ub_aff_from_linexpr0(zonotope_internal_t* pr, elina_linexpr0_t * expr, zonobest_t *zo){
    size_t i;
    elina_dim_t dim;
    elina_coeff_t *coeff;
    zonotope_aff_t *res = zonotope_aff_alloc_init(pr);
    elina_coeff_t * cst = &(expr->cst);
    assert(cst->discr==ELINA_COEFF_SCALAR);
    zonotope_t * lzo = zo->lzo;
    zonotope_t * uzo = zo->uzo;
    res->c_inf = -cst->val.scalar->val.dbl;
    res->c_sup = cst->val.scalar->val.dbl;
    res->itv_inf = -cst->val.scalar->val.dbl;
    res->itv_sup = cst->val.scalar->val.dbl;
   
    elina_linexpr0_ForeachLinterm(expr,i,dim,coeff) {
	assert(coeff->discr==ELINA_COEFF_SCALAR);
        zonotope_aff_t *aff_u = uzo->paf[dim];
	zonotope_aff_t  *aff_l = lzo->paf[dim];
        zonotope_aff_t *tmp;	
        elina_scalar_t * scalar = coeff->val.scalar;
	double lower_bound = lzo->box_inf[dim];
	double upper_bound = uzo->box_sup[dim];
	double lambda = upper_bound/(upper_bound+lower_bound);
	if(upper_bound <= 0){
		continue;
	}
	else if(lower_bound < 0){
		//printf("lb<0\n");
		elina_interval_t *itv_mul = elina_interval_alloc();
		double mul_coeff = scalar->val.dbl;
		//printf("mul_coeff: %g \n",mul_coeff);
		//double add_coeff = mu*scalar->val.dbl;
		elina_interval_set_double(itv_mul,mul_coeff,mul_coeff);
		zonotope_aff_t *tmp1 = res;
		if(elina_scalar_sgn(scalar)<=0){
			//printf("c1\n");
			tmp = zonotope_aff_mul_itv(pr,aff_l,itv_mul);
			//zonotope_aff_fprint(pr,stdout,tmp1);
			//zonotope_aff_fprint(pr,stdout,tmp);
			res = zonotope_aff_add(pr,tmp1,tmp,lzo);
			//printf("add output\n");
			//zonotope_aff_fprint(pr,stdout,res);
		}
		else{
			//printf("c2\n");
			tmp = zonotope_aff_mul_itv(pr,aff_u,itv_mul);
			//printf("add input\n");
			//zonotope_aff_fprint(pr,stdout,tmp1);
			//zonotope_aff_fprint(pr,stdout,tmp);
			res = zonotope_aff_add(pr,tmp1,tmp,uzo);
			//printf("add output\n");
			//zonotope_aff_fprint(pr,stdout,res);
		}
		
		elina_interval_free(itv_mul);
		
        	
        	zonotope_aff_free(pr,tmp);
        	zonotope_aff_free(pr,tmp1);
	}
	else if(elina_scalar_sgn(scalar)<=0){
		//printf("scalar<=0\n");
		elina_interval_t *itv_mul = elina_interval_alloc();
		double mul_coeff = lambda*scalar->val.dbl;
		
		//double add_coeff = mu*scalar->val.dbl;
		elina_interval_set_double(itv_mul,mul_coeff,mul_coeff);
		//if(lzo->box_sup[dim]<0 && uzo->box_inf[dim]>0){
		//	tmp = zonotope_aff_mul_itv(pr,aff_u,itv_mul);
		//}
		//else{
			tmp = zonotope_aff_mul_itv(pr,aff_l,itv_mul);
		//}
		elina_interval_free(itv_mul);
		zonotope_aff_t *tmp1 = res;
        	zonotope_aff_t *tmp2 = zonotope_aff_add(pr,tmp1,tmp,lzo);
		//double area1 = 0.5*upper_bound*(upper_bound+lower_bound);
		//double area2 = (0.5*lower_bound*(upper_bound*upper_bound + (upper_bound+lower_bound)*(upper_bound+lower_bound)))/(2*upper_bound+lower_bound);
		//printf("sup: %g %g\n",tmp2->itv_sup,res->itv_sup);
		//if(0){
		//if(0){
			res = tmp2;
			//printf("coeff ub: %g\n",mul_coeff);
			zonotope_aff_free(pr,tmp);
        		zonotope_aff_free(pr,tmp1);
		//}
		//else{
		//	zonotope_aff_free(pr,tmp);
		//	zonotope_aff_free(pr,tmp2);
		//}
		
        	
	}
	else{
		//printf("ub: %u\n",dim);
		//printf("scalar>0\n");
		
		double mu = lower_bound*lambda;
		elina_interval_t *itv_mul = elina_interval_alloc();
		double mul_coeff = lambda*scalar->val.dbl;
		double add_coeff = mu*scalar->val.dbl;
		//printf("lambda: %g mu: %g mul_coeff: %g add_coeff: %g\n",lambda,mu,mul_coeff,add_coeff);
		//double add_coeff = mu*scalar->val.dbl;
		elina_interval_set_double(itv_mul,mul_coeff,mul_coeff);
		tmp = zonotope_aff_mul_itv(pr,aff_u,itv_mul);
		elina_interval_free(itv_mul);
		zonotope_aff_t *tmp1 = res;
        	res = zonotope_aff_add(pr,tmp1,tmp,uzo);
		res->c_inf = res->c_inf - add_coeff;
		res->c_sup = res->c_sup + add_coeff;
		res->itv_inf = res->itv_inf - add_coeff;
		res->itv_sup = res->itv_sup + add_coeff;
        	zonotope_aff_free(pr,tmp);
        	zonotope_aff_free(pr,tmp1);
	}
	printf("i: %d dim: %d %g %g\n",i,dim,-res->c_inf,res->c_sup);
        zonotope_aff_fprint(pr,stdout,res);
	
    }
	
    return res;
}


zonotope_aff_t * zonotope_lb_aff_from_linexpr0(zonotope_internal_t* pr, elina_linexpr0_t * expr, zonobest_t *zo){
    size_t i;
    elina_dim_t dim;
    elina_coeff_t *coeff;
    zonotope_aff_t *res = zonotope_aff_alloc_init(pr);
    elina_coeff_t * cst = &(expr->cst);
    assert(cst->discr==ELINA_COEFF_SCALAR);
    zonotope_t * lzo = zo->lzo;
    zonotope_t * uzo = zo->uzo;
    res->c_inf = -cst->val.scalar->val.dbl;
    res->c_sup = cst->val.scalar->val.dbl;
    res->itv_inf = -cst->val.scalar->val.dbl;
    res->itv_sup = cst->val.scalar->val.dbl;
   
    elina_linexpr0_ForeachLinterm(expr,i,dim,coeff) {
	assert(coeff->discr==ELINA_COEFF_SCALAR);
        zonotope_aff_t *aff_l = lzo->paf[dim];
	zonotope_aff_t *aff_u = uzo->paf[dim];
        zonotope_aff_t *tmp;	
        elina_scalar_t * scalar = coeff->val.scalar;
	double lower_bound = lzo->box_inf[dim];
	double upper_bound = uzo->box_sup[dim];
	double lambda = upper_bound/(upper_bound+lower_bound);
	if(upper_bound <= 0){
		continue;
	}
	else if(lower_bound < 0){
		//printf("lb: %u\n",dim);
		elina_interval_t *itv_mul = elina_interval_alloc();
		double mul_coeff = scalar->val.dbl;
		//printf("mul_coeff: %g \n",mul_coeff);
		//double add_coeff = mu*scalar->val.dbl;
		elina_interval_set_double(itv_mul,mul_coeff,mul_coeff);
		zonotope_aff_t *tmp1 = res;
		if(elina_scalar_sgn(scalar)>=0){
			tmp = zonotope_aff_mul_itv(pr,aff_l,itv_mul);
			res = zonotope_aff_add(pr,tmp1,tmp,lzo);
		}
		else{
			tmp = zonotope_aff_mul_itv(pr,aff_u,itv_mul);
			res = zonotope_aff_add(pr,tmp1,tmp,uzo);
		}
		
		elina_interval_free(itv_mul);
		
        	
        	zonotope_aff_free(pr,tmp);
        	zonotope_aff_free(pr,tmp1);
	}
	else if(elina_scalar_sgn(scalar)>=0){
		elina_interval_t *itv_mul = elina_interval_alloc();
		double mul_coeff = lambda*scalar->val.dbl;
		
		//double add_coeff = mu*scalar->val.dbl;
		elina_interval_set_double(itv_mul,mul_coeff,mul_coeff);
		//if(lzo->box_sup[dim]<0 && uzo->box_inf[dim]>0){
		//	tmp = zonotope_aff_mul_itv(pr,aff_u,itv_mul);
		//}
		//else{
			tmp = zonotope_aff_mul_itv(pr,aff_l,itv_mul);
		//}
		//double area1 = 0.5*upper_bound*(upper_bound+lower_bound);
		//double area2 = (0.5*lower_bound*(upper_bound*upper_bound + (upper_bound+lower_bound)*(upper_bound+lower_bound)))/(2*upper_bound+lower_bound);
		elina_interval_free(itv_mul);
		zonotope_aff_t *tmp1 = res;
        	zonotope_aff_t *tmp2 = zonotope_aff_add(pr,tmp1,tmp,lzo);
		//if(0){
		//if(1){
			//printf("coeff lb: %g\n",mul_coeff);
			res = tmp2;
			zonotope_aff_free(pr,tmp);
        		zonotope_aff_free(pr,tmp1);
		//}
		//else{
		//	zonotope_aff_free(pr,tmp);
		//	zonotope_aff_free(pr,tmp2);
		//}
	}
	else{
		//printf("lb: %u\n",dim);
		
		double mu = lower_bound*lambda;
		elina_interval_t *itv_mul = elina_interval_alloc();
		double mul_coeff = lambda*scalar->val.dbl;
		double add_coeff = mu*scalar->val.dbl;
		//printf("lambda: %g mu: %g mul_coeff: %g add_coeff: %g\n",lambda,mu,mul_coeff,add_coeff);
		//double add_coeff = mu*scalar->val.dbl;
		elina_interval_set_double(itv_mul,mul_coeff,mul_coeff);
		tmp = zonotope_aff_mul_itv(pr,aff_u,itv_mul);
		elina_interval_free(itv_mul);
		zonotope_aff_t *tmp1 = res;
        	res = zonotope_aff_add(pr,tmp1,tmp,uzo);
		res->c_inf = res->c_inf - add_coeff;
		res->c_sup = res->c_sup + add_coeff;
		res->itv_inf = res->itv_inf - add_coeff;
		res->itv_sup = res->itv_sup + add_coeff;
        	zonotope_aff_free(pr,tmp);
        	zonotope_aff_free(pr,tmp1);
	}
        
	//printf("lb i: %d dim: %d\n",i,dim);
        //zonotope_aff_fprint(pr,stdout,res);
    }
	
    return res;
}

elina_abstract0_t* zonobest_relu_assign_linexpr_array(elina_manager_t* man, bool destructive, elina_abstract0_t* element, elina_dim_t* tdim, elina_linexpr0_t** lexpr, size_t size){
	zonobest_t *zo = zonobest_of_abstract0(element);
	zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
	zonotope_internal_t *zpr = zonotope_init_from_manager(pr->man_zono, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
    	zonobest_t* res = zonobest_copy(man, zo);
	//printf("assign input\n");
	//zonobest_fprint(stdout,man,zo,NULL);
	//fflush(stdout);
    	size_t i = 0;
	zonotope_t *lzo = res->lzo;
	zonotope_t *uzo = res->uzo;
    	for (i=0; i< lzo->dims; i++) {
		lzo->paf[i]->itv_inf = lzo->box_inf[i];
		lzo->paf[i]->itv_sup = lzo->box_sup[i];
    	}
	for(i=0; i < uzo->dims; i++){
		uzo->paf[i]->itv_inf = uzo->box_inf[i];
		uzo->paf[i]->itv_sup = uzo->box_sup[i];
	}
    for (i=0; i<size; i++) {
	zonotope_aff_check_free(zpr, lzo->paf[tdim[i]]);
	zonotope_aff_check_free(zpr, uzo->paf[tdim[i]]);
	//printf("statement x%d:= \n",tdim[i]);
	//elina_linexpr0_fprint(stdout,lexpr[i],NULL);
        //printf("\n");
	//fflush(stdout);
        //
	lzo->paf[tdim[i]] = zonotope_lb_aff_from_linexpr0(zpr, lexpr[i], zo);
	
        
        
	
	//zonotope_aff_reduce(zpr, lzo->paf[tdim[i]]);
      
	if (zonotope_aff_is_top(zpr, lzo->paf[tdim[i]])) {
	    zonotope_aff_check_free(zpr, lzo->paf[tdim[i]]);
	    lzo->paf[tdim[i]] = zpr->top;
	} else if (zonotope_aff_is_bottom(zpr, lzo->paf[tdim[i]])) {
	    zonotope_aff_check_free(zpr, lzo->paf[tdim[i]]);
	    lzo->paf[tdim[i]] = zpr->bot;
	}
	lzo->box_inf[tdim[i]] = lzo->paf[tdim[i]]->itv_inf;
	lzo->box_sup[tdim[i]] = lzo->paf[tdim[i]]->itv_sup;
	lzo->paf[tdim[i]]->pby++;

	//printf("lb affine expression\n");
        //zonotope_aff_fprint(zpr,stdout,lzo->paf[tdim[i]]);

	uzo->paf[tdim[i]] = zonotope_ub_aff_from_linexpr0(zpr, lexpr[i], zo);
	
       // printf("affine expression\n");
        //zonotope_aff_fprint(pr,stdout,res->paf[tdim[i]]);
        //
	
	//zonotope_aff_reduce(zpr, uzo->paf[tdim[i]]);
      
	if (zonotope_aff_is_top(zpr, uzo->paf[tdim[i]])) {
	    zonotope_aff_check_free(zpr, uzo->paf[tdim[i]]);
	    uzo->paf[tdim[i]] = zpr->top;
	} else if (zonotope_aff_is_bottom(zpr, uzo->paf[tdim[i]])) {
	    zonotope_aff_check_free(zpr, uzo->paf[tdim[i]]);
	    uzo->paf[tdim[i]] = zpr->bot;
	}
	uzo->box_inf[tdim[i]] = uzo->paf[tdim[i]]->itv_inf;
	uzo->box_sup[tdim[i]] = uzo->paf[tdim[i]]->itv_sup;
	uzo->paf[tdim[i]]->pby++;
	
	//fflush(stdout);
	//printf("ub affine expression\n");
        //zonotope_aff_fprint(zpr,stdout,uzo->paf[tdim[i]]);
    }
    man->result.flag_best = false;
    man->result.flag_exact = false;
	//printf("assign  output %d %d\n",res->lzo->size,res->uzo->size);
	//zonotope_fprint(stdout,pr->man_zono,res->lzo,NULL);
	//zonotope_fprint(stdout,pr->man_zono,res->uzo,NULL);
    return abstract0_of_zonobest(man,res);
}




bool zonobest_sat_hypothesis_cons(elina_manager_t* man, elina_abstract0_t *element, elina_dim_t y, elina_dim_t x){
	zonobest_t *zo = zonobest_of_abstract0(element);
	zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
	zonotope_internal_t *zpr = zonotope_init_from_manager(pr->man_zono, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
	zonotope_t *lzo = zo->lzo;
	zonotope_t *uzo = zo->uzo;
	//printf("input: %d %d\n",y,x);
	//zonotope_aff_fprint(zpr,stdout,lzo->paf[y]);
	//zonotope_aff_fprint(zpr,stdout,uzo->paf[y]);
	//zonotope_aff_fprint(zpr,stdout,lzo->paf[x]);
	//zonotope_aff_fprint(zpr,stdout,uzo->paf[x]);
	double box_inf = 0.0;
    	double box_sup = 0.0;
    	double tmp_inf = 0.0;
    	double tmp_sup = 0.0;
    
    	zonotope_aff_t* res = zonotope_aff_alloc_init(zpr);
    	zonotope_aaterm_t *p, *q, *ptr;
    	res->c_inf = lzo->paf[y]->c_inf + uzo->paf[x]->c_sup;
    	res->c_sup = lzo->paf[y]->c_sup + uzo->paf[x]->c_inf;
	
    	box_inf = res->c_inf;
   	box_sup = res->c_sup;
    	
    if (lzo->paf[y]->q || uzo->paf[x]->q) {
        
        ptr = zonotope_aaterm_alloc_init();
	zonotope_t *abs = NULL;
        for(p = lzo->paf[y]->q, q = uzo->paf[x]->q; p || q;) {
            
            if (p && q) {
                
                if (p->pnsym->index == q->pnsym->index) {
		    ptr->inf = p->inf + q->sup;
		    ptr->sup = p->sup + q->inf;
                    ptr->pnsym = p->pnsym;
		    abs = lzo;
                    p = p->n ;
                    q = q->n ;
                } else if (p->pnsym->index < q->pnsym->index) {
		    ptr->inf = p->inf;
		    ptr->sup = p->sup;
                    ptr->pnsym = p->pnsym;
		    abs = lzo;
                    p = p->n ;
                } else {
		    ptr->inf = q->inf;
		    ptr->sup = q->sup;
                    ptr->pnsym = q->pnsym;
		    abs = uzo;
                    q = q->n ;
                }
                
            } else if (p) {
		ptr->inf = p->inf;
		ptr->sup = p->sup;
                ptr->pnsym = p->pnsym;
		abs = lzo;
                p = p->n ;
            } else {
		ptr->inf = q->inf;
		ptr->sup = q->sup;
                ptr->pnsym = q->pnsym;
		abs = uzo;
                q = q->n ;
            }
            
            if (!ptr->inf && !ptr->sup) {
                if (!(p||q)) {
                    /* the last iteration */
                    zonotope_aaterm_free(zpr, ptr);
                    if (res->end) res->end->n = NULL;
                }
            } else {
                /* keep this term */
               
                if (!res->q) res->q = ptr;
                res->end = ptr;
                res->l++;
               
                zonotope_noise_symbol_cons_get_gamma(zpr, &tmp_inf, &tmp_sup, ptr->pnsym->index, abs);
		double inf = 0.0;
		double sup = 0.0;
                elina_double_interval_mul(&inf,&sup,tmp_inf,tmp_sup,ptr->inf,ptr->sup);
                box_inf =  box_inf + sup;
                box_sup =  box_sup + inf;
                 //start_timing();
                if (p||q) {
                    /* continuing */
                    ptr->n = zonotope_aaterm_alloc_init();
                    ptr=ptr->n;
                }
                 //record_timing(zonotope_assign_linexpr_time);
            }
            
        }
        
    }
    
    res->itv_inf =  lzo->paf[y]->itv_inf + uzo->paf[x]->itv_sup;
    res->itv_sup =  lzo->paf[y]->itv_sup + uzo->paf[x]->itv_inf;
	
	
    res->itv_inf = fmin(res->itv_inf,box_inf);
    res->itv_sup = fmin(res->itv_sup,box_sup);
	//printf("output\n");
	//zonotope_aff_fprint(zpr,stdout,res);
	if(res->itv_inf<0){
		return true;
	}
	else{
		return false;
	}
}


elina_abstract0_t* zonobest_relu_last_layer(elina_manager_t* man, bool destructive, elina_abstract0_t* element){
	zonobest_t *zo = zonobest_of_abstract0(element);
	zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
	zonotope_internal_t *zpr = zonotope_init_from_manager(pr->man_zono, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
	//printf("assign input\n");
	//zonobest_fprint(stdout,man,zo,NULL);
	//fflush(stdout);
    	zonobest_t* res = destructive? zo : zonobest_copy(man,zo);
    	size_t i = 0;
	zonotope_t *lzo = res->lzo;
	zonotope_t *uzo = res->uzo;
	elina_dim_t *tdim = (elina_dim_t *)malloc(sizeof(elina_dim_t));
    	for (i=0; i< lzo->dims; i++) {
		tdim[0] = i; 
		if(lzo->box_inf[i]<0){
			continue;
		}	
		else if(uzo->box_sup[i]<=0){
			//printf("coming here %d\n",i);	
			elina_linexpr0_t * expr = elina_linexpr0_alloc(ELINA_LINEXPR_SPARSE,0);
			elina_coeff_t *cst = &expr->cst;
			elina_coeff_set_scalar_double(cst,0.0);
			res->lzo = zonotope_assign_linexpr_array(pr->man_zono,true,res->lzo,tdim,&expr,1,NULL);
			res->uzo = zonotope_assign_linexpr_array(pr->man_zono,true,res->uzo,tdim,&expr,1,NULL);
		}
		else{
			//printf("both bounds: %d\n",i);
			elina_linexpr0_t * lexpr = elina_linexpr0_alloc(ELINA_LINEXPR_SPARSE,1);
			elina_coeff_t *cst = &lexpr->cst;
			elina_coeff_set_scalar_double(cst,0.0);
			res->lzo = zonotope_assign_linexpr_array(pr->man_zono,true,res->lzo,tdim,&lexpr,1,NULL);
			elina_linexpr0_t * uexpr = elina_linexpr0_alloc(ELINA_LINEXPR_SPARSE,1);
			cst = &uexpr->cst;
			double ub = uzo->box_sup[i];
			double lb = lzo->box_inf[i];
			double lambda = ub/(ub+lb);
			double mu = lb*lambda;
			elina_coeff_set_interval_double(cst,mu,mu);
			elina_linterm_t * linterm = &uexpr->p.linterm[0];
			linterm->dim = i;
			elina_coeff_t *coeff = &linterm->coeff;
			elina_coeff_set_interval_double(coeff,lambda,lambda);
			res->uzo = zonotope_assign_linexpr_array(pr->man_zono,true,res->uzo,tdim,&uexpr,1,NULL);
		}
		
    	}
	free(tdim);
   
    man->result.flag_best = false;
    man->result.flag_exact = false;
	//printf("assign output\n");
	//zonobest_fprint(stdout,man,res,NULL);
	//fflush(stdout);
    return abstract0_of_zonobest(man,res);
}

elina_abstract0_t * zonobest_maxpool(elina_manager_t *man, bool destructive, elina_abstract0_t * element, elina_dim_t y, elina_dim_t* x, size_t size){
	zonobest_t *zo = zonobest_of_abstract0(element);
	zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
	zonotope_internal_t *zpr = zonotope_init_from_manager(pr->man_zono, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
	zonobest_t* res = destructive? zo : zonobest_copy(man,zo);
	elina_dim_t *tdim = (elina_dim_t *)malloc(sizeof(elina_dim_t));
	size_t i = 0;
	double sum_l = 0.0;
	double max_l = -INFINITY;
	size_t ind_l = 0.0;
	tdim[0] = y;
	for(i=0; i < size; i++){
		elina_interval_t * bound = zonobest_bound_dimension(man,zo,x[i]);
		double lb = bound->inf->val.dbl;
		//double ub = bound->sup->val.dbl;
		sum_l = sum_l + lb;
		if(lb>max_l){
			max_l = lb;
			ind_l = x[i];
		} 
		elina_interval_free(bound);
	}
	elina_linexpr0_t * lexpr = elina_linexpr0_alloc(ELINA_LINEXPR_SPARSE,1);
	elina_coeff_t *cst = &lexpr->cst;
	elina_coeff_set_scalar_double(cst,0.0);
	elina_linterm_t * linterm = &lexpr->p.linterm[0];
	linterm->dim = ind_l;
	elina_coeff_t *coeff = &linterm->coeff;
	elina_coeff_set_scalar_double(coeff,1.0);	
	res->lzo = zonotope_assign_linexpr_array(pr->man_zono,true,res->lzo,tdim,&lexpr,1,NULL);

	elina_linexpr0_t * uexpr = elina_linexpr0_alloc(ELINA_LINEXPR_SPARSE,1);
	cst = &uexpr->cst;
	elina_coeff_set_scalar_double(cst,max_l-sum_l);
	
	for(i=0; i < size; i++){
		elina_linterm_t * linterm = &uexpr->p.linterm[i];
		linterm->dim = x[i];
		elina_coeff_t *coeff = &linterm->coeff;
		elina_coeff_set_scalar_double(coeff,1.0);
	}

	res->uzo = zonotope_assign_linexpr_array(pr->man_zono,true,res->uzo,tdim,&uexpr,1,NULL);
		
	man->result.flag_best = false;
    	man->result.flag_exact = false;
	free(tdim);
	//printf("assign output\n");
	//zonobest_fprint(stdout,man,res,NULL);
	//fflush(stdout);
    	return abstract0_of_zonobest(man,res);
}



/*elina_abstract0_t * zonobest_assign_after_maxpool(elina_manager_t* man, bool destructive, elina_abstract0_t* element, elina_dim_t* tdim, elina_linexpr0_t** lexpr, size_t size){
	zonobest_t *zo = zonobest_of_abstract0(element);
	zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
	zonotope_internal_t *zpr = zonotope_init_from_manager(pr->man_zono, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
	zonobest_t* res = destructive? zo : zonobest_copy(man,zo);
	
	size_t i = 0;
	zonotope_t *lzo = res->lzo;
	zonotope_t *uzo = res->uzo;
    	for (i=0; i< lzo->dims; i++) {
		lzo->paf[i]->itv_inf = lzo->box_inf[i];
		lzo->paf[i]->itv_sup = lzo->box_sup[i];
    	}
	for(i=0; i < uzo->dims; i++){
		uzo->paf[i]->itv_inf = uzo->box_inf[i];
		uzo->paf[i]->itv_sup = uzo->box_sup[i];
	}
    	for (i=0; i<size; i++) {
		zonotope_aff_check_free(zpr, lzo->paf[tdim[i]]);
		zonotope_aff_check_free(zpr, uzo->paf[tdim[i]]);
		//printf("statement x%d:= \n",tdim[i]);
		//elina_linexpr0_fprint(stdout,lexpr[i],NULL);
	      // printf("\n");
		//fflush(stdout);
        	//
		lzo->paf[tdim[i]] = zonotope_lb_aff_from_linexpr0_maxpool(zpr, lexpr[i], zo);
	
        
        
	
		zonotope_aff_reduce(zpr, lzo->paf[tdim[i]]);
      
		if (zonotope_aff_is_top(zpr, lzo->paf[tdim[i]])) {
	    		zonotope_aff_check_free(zpr, lzo->paf[tdim[i]]);
	    		lzo->paf[tdim[i]] = zpr->top;
		} else if (zonotope_aff_is_bottom(zpr, lzo->paf[tdim[i]])) {
	    		zonotope_aff_check_free(zpr, lzo->paf[tdim[i]]);
	    		lzo->paf[tdim[i]] = zpr->bot;
		}
		lzo->box_inf[tdim[i]] = lzo->paf[tdim[i]]->itv_inf;
		lzo->box_sup[tdim[i]] = lzo->paf[tdim[i]]->itv_sup;
		lzo->paf[tdim[i]]->pby++;

		//printf("lb affine expression\n");
		//zonotope_aff_fprint(zpr,stdout,lzo->paf[tdim[i]]);

		uzo->paf[tdim[i]] = zonotope_ub_aff_from_linexpr0_maxpool(zpr, lexpr[i], zo);
		
	       // printf("affine expression\n");
		//zonotope_aff_fprint(pr,stdout,res->paf[tdim[i]]);
		//
		
		zonotope_aff_reduce(zpr, uzo->paf[tdim[i]]);
	      
		if (zonotope_aff_is_top(zpr, uzo->paf[tdim[i]])) {
		    zonotope_aff_check_free(zpr, uzo->paf[tdim[i]]);
		    uzo->paf[tdim[i]] = zpr->top;
		} else if (zonotope_aff_is_bottom(zpr, uzo->paf[tdim[i]])) {
		    zonotope_aff_check_free(zpr, uzo->paf[tdim[i]]);
		    uzo->paf[tdim[i]] = zpr->bot;
		}
		uzo->box_inf[tdim[i]] = uzo->paf[tdim[i]]->itv_inf;
		uzo->box_sup[tdim[i]] = uzo->paf[tdim[i]]->itv_sup;
		uzo->paf[tdim[i]]->pby++;
		//printf("assign output\n");
		//zonotope_fprint(stdout,man,res,NULL);
		//fflush(stdout);
		//printf("ub affine expression\n");
		//zonotope_aff_fprint(zpr,stdout,uzo->paf[tdim[i]]);
    }
	
		
	man->result.flag_best = false;
    	man->result.flag_exact = false;
	//printf("assign output\n");
	//zonobest_fprint(stdout,man,res,NULL);
	//fflush(stdout);
    	return abstract0_of_zonobest(man,res);
}


zonotope_t * zonotope_assign_lb_linexpr_array (elina_manager_t* man, bool destructive, zonobest_t* zo, 
				      elina_dim_t* tdim, elina_linexpr0_t** lexpr, 
				      size_t size, zonotope_t* dest){
	zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
	zonotope_internal_t *zpr = zonotope_init_from_manager(pr->man_zono, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
	zonotope_t* res = destructive? zo : zonotope_copy(pr->man_zono,zo->lzo);
	size_t i = 0;
	elina_dim_t dim;
    	elina_coeff_t *coeff;
    	for (i=0; i<res->dims; i++) {
        	//fflush(stdout);
		res->paf[i]->itv_inf = res->box_inf[i];
		res->paf[i]->itv_sup = res->box_sup[i];
    	}
    	for (i=0; i<size; i++) {
		zonotope_aff_check_free(zpr, res->paf[tdim[i]]);
		//printf("statement x%d:= \n",tdim[i]);
		//elina_linexpr0_fprint(stdout,lexpr[i],NULL);
	      // printf("\n");
		//fflush(stdout);
		//
		//res->paf[tdim[i]] = zonotope_aff_from_linexpr0(zpr, lexpr[i], z);
		
    		res->paf[tdim[i]] = zonotope_aff_alloc_init(zpr);
    		elina_coeff_t * cst = &(expr->cst);
    		assert(cst->discr==ELINA_COEFF_SCALAR);
    		zonotope_t * lzo = zo->lzo;
    		zonotope_t * uzo = zo->uzo;
    		res->paf[tdim[i]]->c_inf = -cst->val.scalar->val.dbl;
    		res->paf[tdim[i]]->c_sup = cst->val.scalar->val.dbl;
    		res->paf[tdim[i]]->itv_inf = -cst->val.scalar->val.dbl;
    		res->paf[tdim[i]]->itv_sup = cst->val.scalar->val.dbl;
   
    		elina_linexpr0_ForeachLinterm(expr,i,dim,coeff) {
			assert(coeff->discr==ELINA_COEFF_SCALAR);
        		zonotope_aff_t *aff = uzo->paf[dim];
        		zonotope_aff_t *tmp;	
        		elina_scalar_t * scalar = coeff->val.scalar;
			double lower_bound = lzo->box_inf[dim];
			double upper_bound = uzo->box_sup[dim];
			if(upper_bound < 0){
				continue;
			}
			else if(lower_bound < 0){
				//printf("ub: %u\n",dim);
				elina_interval_t *itv_mul = elina_interval_alloc();
				double mul_coeff = scalar->val.dbl;
				//printf("mul_coeff: %g \n",mul_coeff);
				//double add_coeff = mu*scalar->val.dbl;
				elina_interval_set_double(itv_mul,mul_coeff,mul_coeff);
				tmp = zonotope_aff_mul_itv(pr,aff,itv_mul);
				elina_interval_free(itv_mul);
				zonotope_aff_t *tmp1 = res;
				res = zonotope_aff_add(pr,tmp1,tmp,uzo);
				zonotope_aff_free(pr,tmp);
				zonotope_aff_free(pr,tmp1);
			}
			else if(elina_scalar_sgn(scalar)<=0){
				elina_interval_t *itv_mul = elina_interval_alloc();
				double mul_coeff = scalar->val.dbl;
				
				//double add_coeff = mu*scalar->val.dbl;
				elina_interval_set_double(itv_mul,mul_coeff,mul_coeff);
				tmp = zonotope_aff_mul_itv(pr,aff,itv_mul);
				elina_interval_free(itv_mul);
				zonotope_aff_t *tmp1 = res;
				zonotope_aff_t *tmp2 = zonotope_aff_add(pr,tmp1,tmp,uzo);
				if(tmp2->itv_sup<res->itv_sup){
				//if(0){
					res = tmp2;
					//printf("coeff: %g\n",mul_coeff);
					zonotope_aff_free(pr,tmp);
					zonotope_aff_free(pr,tmp1);
				}
				else{
					zonotope_aff_free(pr,tmp);
					zonotope_aff_free(pr,tmp2);
				}
				
				
			}
			else{
				//printf("ub: %u\n",dim);
				double ub = uzo->box_sup[dim];
				double lb = lzo->box_inf[dim];
				double lambda = ub/(ub+lb);
				double mu = lb*lambda;
				elina_interval_t *itv_mul = elina_interval_alloc();
				double mul_coeff = lambda*scalar->val.dbl;
				double add_coeff = mu*scalar->val.dbl;
				//printf("lambda: %g mu: %g mul_coeff: %g add_coeff: %g\n",lambda,mu,mul_coeff,add_coeff);
				//double add_coeff = mu*scalar->val.dbl;
				elina_interval_set_double(itv_mul,mul_coeff,mul_coeff);
				tmp = zonotope_aff_mul_itv(pr,aff,itv_mul);
				elina_interval_free(itv_mul);
				zonotope_aff_t *tmp1 = res;
				res = zonotope_aff_add(pr,tmp1,tmp,uzo);
				res->c_inf = res->c_inf - add_coeff;
				res->c_sup = res->c_sup + add_coeff;
				res->itv_inf = res->itv_inf - add_coeff;
				res->itv_sup = res->itv_sup + add_coeff;
				zonotope_aff_free(pr,tmp);
				zonotope_aff_free(pr,tmp1);
			}
			
			
		    }
	       // printf("affine expression\n");
		//zonotope_aff_fprint(pr,stdout,res->paf[tdim[i]]);
		//
		//printf("center here1 %g %g\n",res->paf[tdim[i]]->c_inf,res->paf[tdim[i]]->c_sup);
		zonotope_aff_reduce(zpr, res->paf[tdim[i]]);
		//printf("center here2 %g %g\n",res->paf[tdim[i]]->c_inf,res->paf[tdim[i]]->c_sup);
		if (zonotope_aff_is_top(zpr, res->paf[tdim[i]])) {
		    zonotope_aff_check_free(zpr, res->paf[tdim[i]]);
		    res->paf[tdim[i]] = zpr->top;
		} else if (zonotope_aff_is_bottom(zpr, res->paf[tdim[i]])) {
		    zonotope_aff_check_free(zpr, res->paf[tdim[i]]);
		    res->paf[tdim[i]] = zpr->bot;
		}
		res->box_inf[tdim[i]] = res->paf[tdim[i]]->itv_inf;
		res->box_sup[tdim[i]] = res->paf[tdim[i]]->itv_sup;
		res->paf[tdim[i]]->pby++;
		//printf("assign output\n");
		//zonotope_fprint(stdout,man,res,NULL);
		//fflush(stdout);
    	}
   	man->result.flag_best = false;
    	man->result.flag_exact = false;
	return res;
}

zonotope_t * zonotope_assign_ub_linexpr_array (elina_manager_t* man, bool destructive, zonobest_t* zo, 
				      elina_dim_t* tdim, elina_linexpr0_t** lexpr, 
				      size_t size, zonotope_t* dest){
	zonobest_internal_t* pr = zonobest_init_from_manager(man, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
	zonotope_internal_t *zpr = zonotope_init_from_manager(pr->man_zono, ELINA_FUNID_ASSIGN_LINEXPR_ARRAY);
	zonotope_t* res = destructive? zo : zonotope_copy(pr->man_zono,zo->uzo);
	for (i=0; i<res->dims; i++) {
        	//fflush(stdout);
		res->paf[i]->itv_inf = res->box_inf[i];
		res->paf[i]->itv_sup = res->box_sup[i];
    	}
    	for (i=0; i<size; i++) {
		zonotope_aff_check_free(zpr, res->paf[tdim[i]]);
		//printf("statement x%d:= \n",tdim[i]);
		//elina_linexpr0_fprint(stdout,lexpr[i],NULL);
	      // printf("\n");
		//fflush(stdout);
		//
		res->paf[tdim[i]] = zonotope_aff_from_linexpr0(pr, lexpr[i], z);
	       // printf("affine expression\n");
		//zonotope_aff_fprint(pr,stdout,res->paf[tdim[i]]);
		//
		//printf("center here1 %g %g\n",res->paf[tdim[i]]->c_inf,res->paf[tdim[i]]->c_sup);
		zonotope_aff_reduce(zpr, res->paf[tdim[i]]);
		//printf("center here2 %g %g\n",res->paf[tdim[i]]->c_inf,res->paf[tdim[i]]->c_sup);
		if (zonotope_aff_is_top(zpr, res->paf[tdim[i]])) {
		    zonotope_aff_check_free(zpr, res->paf[tdim[i]]);
		    res->paf[tdim[i]] = zpr->top;
		} else if (zonotope_aff_is_bottom(zpr, res->paf[tdim[i]])) {
		    zonotope_aff_check_free(zpr, res->paf[tdim[i]]);
		    res->paf[tdim[i]] = zpr->bot;
		}
		res->box_inf[tdim[i]] = res->paf[tdim[i]]->itv_inf;
		res->box_sup[tdim[i]] = res->paf[tdim[i]]->itv_sup;
		res->paf[tdim[i]]->pby++;
		//printf("assign output\n");
		//zonotope_fprint(stdout,man,res,NULL);
		//fflush(stdout);
    	}
	return res;
}*/



