/*
 *
 *  This source file is part of ELINA (ETH LIbrary for Numerical Analysis).
 *  ELINA is Copyright © 2018 Department of Computer Science, ETH Zurich
 *  This software is distributed under GNU Lesser General Public License Version 3.0.
 *  For more information, see the ELINA project website at:
 *  http://elina.ethz.ch
 *
 *  THE SOFTWARE IS PROVIDED "AS-IS" WITHOUT ANY WARRANTY OF ANY KIND, EITHER
 *  EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO ANY WARRANTY
 *  THAT THE SOFTWARE WILL CONFORM TO SPECIFICATIONS OR BE ERROR-FREE AND ANY
 *  IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE,
 *  TITLE, OR NON-INFRINGEMENT.  IN NO EVENT SHALL ETH ZURICH BE LIABLE FOR ANY     
 *  DAMAGES, INCLUDING BUT NOT LIMITED TO DIRECT, INDIRECT,
 *  SPECIAL OR CONSEQUENTIAL DAMAGES, ARISING OUT OF, RESULTING FROM, OR IN
 *  ANY WAY CONNECTED WITH THIS SOFTWARE (WHETHER OR NOT BASED UPON WARRANTY,
 *  CONTRACT, TORT OR OTHERWISE).
 *
 */


#ifndef _ZONOBEST_MLTRANSFORMERS_H_
#define _ZONOBEST_MLTRANSFORMERS_H_

#include "zonobest.h"
#include "zonobest_internal.h"
#include "zonobest_fun.h"
#include "zonotope_internal.h"


#ifdef __cplusplus
extern "C" {
#endif

elina_abstract0_t* zonobest_relu_assign_linexpr_array(elina_manager_t* man, bool destructive, elina_abstract0_t* zo, elina_dim_t* tdim, elina_linexpr0_t** lexpr, size_t size);

bool zonobest_sat_hypothesis_cons(elina_manager_t* man, elina_abstract0_t *zo, elina_dim_t y, elina_dim_t x);

elina_abstract0_t* zonobest_relu_last_layer(elina_manager_t* man, bool destructive, elina_abstract0_t* element);

#ifdef __cplusplus
}
#endif

#endif
